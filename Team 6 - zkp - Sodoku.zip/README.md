# Advanced-Cryptography_Zero-Knowledge-Proof

Anatoli Kot 324413756
Eden Barsheshet 203531918
Yuval Varshavsky 207326703
 
 Hello and Welcome to hte zkp - Sodoku Example

 in order to run the program follow this steps :
    1.extract all the files 
    2.make sure that pyhton is installed
    3.run the main.py file using python 
        * Using Terminal - open terminal in the extracted folder and run python main.py OR python3 main.py

        * Using code editor - make sure that you open the main.py file using your code editor
        Press run 
